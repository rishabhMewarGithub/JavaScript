
/******Declaration of an Array******/

var House = [ ]; // method 1
var House = new array(); // method 2


/**** Initialization of an Array *****/

	/**** Example (for Method 1): *****/

		// Initializing while declaring 
		var house = ["1BHK", "2BHK", "3BHK", "4BHK"]; 
		  
		// Initializing after declaring 
		house[0] = "1BHK";   
		house[1] = "2BHK"; 
		house[2] = "3BHK"; 
		house[3] = "4BHK"; 
		
	/**** Example (for Method 2): *****/
	
		// Initializing while declaring 
			// Creates an array having elements 10, 20, 30, 40, 50 
			var house = new Array(10, 20, 30, 40, 50); 
			  
			//Creates an array of 5 undefined elements 
			var house1 = new Array(5); 
			  
			//Creates an array with element 1BHK 
			var home = new Array("1BHK"); 
			
			
/******* An array in JavaScript can hold different elements *******/

	// Storing number, boolean, strings in an Array 
	var house = ["1BHK", 25000, "2BHK", 50000, "Rent", true]; 
	
	
/**** Accessing Array Elements and Length property of an array *******/

	var house = ["1BHK", 25000, "2BHK", 50000, "Rent", true]; 
	alert(house[0]+" cost= "+house[1]); 
	var cost_1BHK = house[1]; 
	var is_for_rent = house[5]; 
	alert("Cost of 1BHK = "+ cost_1BHK); 
	alert("Is house for rent = ")+ is_for_rent);  
	
	//length contains the length of the array 
	var len = house.length; 
	for (var i = 0; i < len; i++) 
		alert(house[i]); 
	
	
	
/***** Array.push() ********/


// Adding elements at the end of an array 
// Declaring and initializing arrays 
var number_arr = [ 10, 20, 30, 40, 50 ]; 
var string_arr = [ "piyush", "gourav", "smruti", "ritu" ]; 
  
// push() 
// number_arr contains [10, 20, 30, 40, 50, 60] 
number_arr.push(60); 
  
// We can pass multiple parameters to the push() 
// number_arr contains 
// [10, 20, 30, 40, 50, 60, 70, 80, 90] 
number_arr.push(70, 80, 90); 
  
// string_arr contains 
// ["piyush", "gourav", "smruti", "ritu", "sumit", "amit"]; 
string_arr.push("sumit", "amit"); 
  
// Printing both the array after performing push operation 
console.log("After push op " + number_arr); 
console.log("After push op " + string_arr); 



/***** Array.unshift() ********/


// Adding element at the beginning of an array 
// Declaring and initializing arrays 
var number_arr = [ 20, 30, 40 ]; 
var string_arr = [ "amit", "sumit" ]; 
  
// unshift() 
// number_arr contains 
// [10, 20, 20, 30, 40] 
number_arr.unshift(10, 20); 
  
// string_arr contains 
// ["sunil", "anil", "amit", "sumit"] 
string_arr.unshift("sunil", "anil"); 
  
// Printing both the array after performing unshift operation 
console.log("After unshift op " + number_arr); 
console.log("After unshift op " + string_arr); 




/***** Array.pop() ********/


// Removing elements from the end of an array 
// Declaring and initializing arrays 
var number_arr = [ 20, 30, 40, 50 ]; 
var string_arr = [ "amit", "sumit", "anil" ]; 
  
// pop() 
// number_arr contains 
// [ 20, 30, 40 ] 
number_arr.pop(); 
  
// string_arr contains 
// ["amit", "sumit"] 
string_arr.pop(); 
  
// Printing both the array after performing pop operation 
console.log("After pop op " + number_arr); 
console.log("After popo op " + string_arr); 



/***** Array.shift() ********/


// Removing element from the beginning of an array 
// Declaring and initializing arrays 
var number_arr = [ 20, 30, 40, 50, 60 ]; 
var string_arr = [ "amit", "sumit", "anil", "prateek" ]; 
  
// shift() 
// number_arr contains 
//  [30, 40, 50, 60]; 
number_arr.shift(); 
  
// string_arr contains 
// ["sumit", "anil", "prateek"] 
string_arr.shift(); 
  
// Printing both the array after performing shifts operation 
console.log("After shift op " + number_arr); 
console.log("After shift op " + string_arr); 





/***** Array.splice() ********/


// Removing an adding element at a particular location 
// in an array 
// Declaring and initializing arrays 
var number_arr = [ 20, 30, 40, 50, 60 ]; 
var string_arr = [ "amit", "sumit", "anil", "prateek" ]; 
  
// splice() 
// deletes 3 elements starting from 1 
// number array contains [20, 60] 
number_arr.splice(1, 3); 
  
// doesn't delete but inserts 3, 4, 5 
// at starting location 1 
number_arr.splice(1, 0, 3, 4, 5); 
  
// deletes two elements starting from index 1 
// and add three elements. 
// It contains  ["amit", "xyz", "geek 1", "geek 2", "prateek"]; 
string_arr.splice(1, 2, "xyz", "geek 1", "geek 2"); 
  
// Printing both the array after performing splice operation 
console.log("After splice op " + number_arr); 
console.log("After splice op " + string_arr); 




/********* Array.findIndex() ***********/


	//array.findIndex(function(currentValue, index, arr), thisValue)

	function isOdd(element, index, array) {
	  return (element%2 == 1);
	}
	print([4, 6, 8, 12].findIndex(isOdd)); // -1

	///////////////
	
	function isOdd(element, index, array) {
	  return (element%2 == 1);
	}
	print([4, 6, 7, 12].findIndex(isOdd)); // 2

	//////////////
	
	// function isPrime is used to find which 
	// number is prime or not prime. 
	function isPrime(n) { 
	  if (n === 1) { 
		return false; 
	  } else if (n === 2) { 
		return true; 
	  } else { 
		for (var x = 2; x < n; x++) { 
		  if (n % x === 0) { 
			return false; 
		  } 
		} 
		return true; 
	  } 
	} 
	// Printing -1 because prime number is not found. 
	console.log([ 4, 6, 8, 12 ].findIndex(isPrime)); 
	// Printing 2 the index of prime number (7) found. 
	console.log([ 4, 6, 7, 12 ].findIndex(isPrime)); 



	
	
	
/******** Array copyWithin() *************/

	//The copyWithin() method copies part of an array to the same array and returns it, 
	//without modifying its size i.e, copies array element of a array within the same array.
	
	//array.copyWithin(target, start, end)

	// Input array 
	var array = [ 1, 2, 3, 4, 5, 6, 7 ]; 
	// placing at index position 0 the element between index 3 and 6 
	console.log(array.copyWithin(0, 3, 6)); // Array [4, 5, 6, 4, 5, 6, 7]
	
	// Input array 
	var array = [ 1, 2, 3, 4, 5, 6, 7 ]; 
	// placing from index position 0 the element from index 4 
	console.log(array.copyWithin(0, 4)); // Array [5, 6, 7, 4, 5, 6, 7]
	
	// Input array 
	var array = [ 1, 2, 3, 4, 5, 6, 7 ]; 
	// placing from index position 3 the element from index 0 
	console.log(array.copyWithin(3)); // Array [1, 2, 3, 1, 2, 3, 4]
	
	// Input array 
	var array = [ 1, 2, 3, 4, 5, 6, 7 ];   
	// placing at index position 0 the element between index 4 and 5 
	console.log(array.copyWithin(0, 4, 5)); // Array [5, 2, 3, 4, 5, 6, 7]
	
	
	

/******** array.values() ***********/

	// Input array contain some elements 
	var A = [ 'Ram', 'Z', 'k', 'geeksforgeeks' ];
	// Here array.values() function is called. 
	var iterator = A.values(); 
	// All the elements of the array the array is being printed. 
	console.log(iterator.next().value); 
	console.log(iterator.next().value); 
	console.log(iterator.next().value); 
	console.log(iterator.next().value); 
	// > Ram, z, k, geeksforgeeks
	
	// Input array contain some elements. 
	var array = [ 'a', 'gfg', 'c', 'n' ]; 
	// Here array.values() function is called. 
	var iterator = array.values(); 
	// Here all the elements of the array is being printed. 
	for (let elements of iterator) { 
	  console.log(elements); 
	} 
	//> a, gfg, c, n
	
	
	
/******** array.toLocaleString()  ***********/

	//used to convert the element of the given array to string.
	//arr.toLocaleString();

	// taking inputs. 
	var name = "geeksforgeeks"; 
	var number = 567;
	// It will give current date and time. 
	var date = new Date();
	// Here A is an array containing elements of above variables. 
	var A = [ name, number, date ];
	// applying array.toLocaleString function. 
	var string = A.toLocaleString(); 
	// printing string. 
	console.log(string); // "geeksforgeeks, 567, 2/18/2018, 10:41:20 AM"
	
	
	// taking inputs. 
	var name = [ "Ram", "Sheeta", "Geeta" ]; 
	var number1 = 3.45; 
	var number2 = [ 23, 34, 54 ]; 
	// Here A is an array containing elements of above variables. 
	var A = [ name, number1, number2 ]; 
	// appling array.toLocaleString function. 
	var string = A.toLocaleString(); 
	// printing string. 
	console.log(string);  // "Ram, Sheeta, Geeta, 3.45, 23, 34, 54"



/*********** Array.of() **************/

	//creates a new array instance with variables present as the argument of the function.
	//Array.of(element0, element1, ....)
	
	// Here the Array.of() method creates a new Array instance with 
	// a variable number of arguments, regardless of 
	// number or type of the arguments. 
	console.log(Array.of(0, 0, 0));       // Array [0, 0, 0]
	console.log(Array.of(11, 21, 33));    // Array [11, 21, 33]
	console.log(Array.of("Ram","Geeta")); // Array ["Ram", "Geeta"]
	console.log(Array.of('geeksforgeeks')); // Array ["geeksforgeeks"]
	console.log(Array.of(2,3,4,'Sheeta'));  // Array [2, 3, 4, "Sheeta"]


/******* Array join() *********/

	//used to join the elements of the array together into a string.
	//Array.join([separator])
	//separator: A string to separate each elements of the array. If leave it by default array element separate by comma( , ).
	//If an empty string is provided as the separator then the elements are joined directly without any character in between them. 
	//If array is empty then this function returns an empty string./
	
	var a = [1, 2, 3, 4, 5, 6];
	console.log(a.join('|')); // 1|2|3|4|5|6
	
	var a = [1, 2, 3, 4, 5, 6];
	console.log(a.join()); // 1, 2, 3, 4, 5, 6
	
	var a = [1, 2, 3, 4, 5, 6];
	console.log(a.join('')); // 123456

	
	
/******** Array fill() **********/

	//used to fill the array with a given static value. 
	//The value can be used to fill the entire array or it can be used to fill a part of the array.
	//arr.fill(value, start, end)
	// If this value is not defined the starting index is taken as 0. 
	//If start is negative then the net start index is length+start.
	//If this value is not defined then by default the last index of the i.e arr.length – 1 is taken as the end value. 
	//If the end is negative, then the net end is defined as length+end.
	
	var arr = [1, 23, 46, 58];
	arr.fill(87);  // [87, 87, 87, 87]
	
	var arr = [1, 23, 46, 58];
	arr.fill(87, 1, 3);  // [1, 87, 87, 58]
	
	var arr = [1, 23, 46, 58];
	arr.fill(87, 2); // [1, 23, 87, 87]
	
	
	
/********** Array.find() ************/

	//used to find the first element from the array that satisfies the condition implemented by a function. 
	//If more than one element satisfies the condition then the first element satisfying the condition is returned.
	//arr.find(function(element, index, array), thisValue)
	//thisValue is used to tell the function to use this value when executing argument function.
	//If no value satisfies the given condition, then it returns undefined as its answer.

	function isOdd(element, index, array) {
		return (element%2 == 1);
	}
	print([4, 6, 8, 12].find(isOdd)); // undefined
	
	//Whenever we need to get the value of the first element in the array that 
	//satisfies the provided testing function that time we use Array.find() method.
	
	
	
/******** Array.concat() *********/
	
	//Array.concat() function is used to merge two or more arrays together. 
	//This function does not alter the original arrays passed as arguments.
	//var new_array = old_array.concat(value1[, value2[, ...[, valueN]]])
	
	
	var num1 = [11, 12, 13],
		num2 = [14, 15, 16],
		num3 = [17, 18, 19];
	print(num1.concat(num2, num3)); // [11,12,13,14,15,16,17,18,19]
	
	var alpha = ['a', 'b', 'c'];
	print(alpha.concat(1, [2, 3]));
	
	var num1 = [[23]];
	var num2 = [89, [67]];
	print(num1.concat(num2)); // [23,89,67] 
	
	
	
	
/********* Array.from() ***************/

	//creates a new array instance from a given array. 
	//In case of a string, every alphabet of the string is converted to an element of the new array instance 
	//and in case of integer values, new array instance simple take the elements of the given array.
	/**Array.from(mapFn,thisArg)
		Parameters:
		mapFn (Optional): Map function to call on every element of the array.
		thisArg (Optional):Value to use as this when executing mapFn.**/
	
	Input : geeksforgeeks
	Output : Array ["g", "e", "e", "k", "s", "f", "o", "r", "g", "e", "e", "k", "s"]
	
	Input : 10, 20, 30
	Output :  Array [10, 20, 30]
	
	console.log(Array.from(1+2i)); // Invalid or unexpected token
	
	//Whenever we need to do any operation with the elements of the array that time we can 
	//take help of the Array.from() method in javaScript.
	
	console.log(Array.from([1, 2, 3], x => x + x)); // Array [2, 4, 6]
	
	
	
	
	
	
/******** Array.prototype.every() *********/
	
	//To check if every element of the integer array is less than 100
		function fnIsLEssThan100_loop(arr){ 
			for(var i = 0 ; i < arr.length; i ++){ 
				if(arr[i] >= 100){ 
					return false; 
				} 
			} 
			return true; 
		} 
		function fnIsLEssThan100_loop([30,60,90]); 
		function fnIsLEssThan100_loop([30,60,90,120]); 
		
		
		function fnIsLesThan100_Every(arr){ 
			return arr.every(function(element){ 
				return(element < 100): 
			}); 
		} 
		fnIsLesThan100_Every([30,60,90]) 
		fnIsLesThan100_Every([30,60,90,120]) 

		
	//To check if every element of the array is of a specific data type, for example String.
		function fnCheckDatatype_loop(arr. sDatatype){ 
			for(var i = 0 ; i < arr.length; i ++){ 
				if(typeof(arr[i]) !== sDatatype){ 
					return false; 
				}
			}
		}
		fnCheckDatatype_loop(["Geeks","for","Geeks"],"string") 
		fnCheckDatatype_loop(["Geeks",4,"Geeks"],"string") 
		
		
		function fnCheckDatatype_Every(arr, sDatatype){ 
			return arr.every(function(element){ 
				return typeof(element) === sDatatype; 
			},sDatatype); 
		} 
		fnCheckDatatype_loop(["Geeks","for","Geeks"],"string") 
		fnCheckDatatype_loop(["Geeks",4,"Geeks"],"string") 
	
	
	

/******** Array.prototype.some() ************/

	//To check if any element of the array greater than 100.
		function fnIsGreaterThan100_loop(arr){ 
			for(var i = 0 ; i < arr.length; i ++){ 
				if(arr[i] > 100){ 
					return true; 
				} 
			} 
			return false; 
		} 
		fnIsGreaterThan100_loop([30,60,90,120]); 
		fnIsGreaterThan100_loop([30,60,90]); 
		
		
		function fnIsGreaterThan100_some(arr){ 
			return arr.some(function(element){ 
				return(element.100): 
			}); 
		} 
		fnIsGreaterThan100_some([30,60,90,120]); 
		fnIsGreaterThan100_some([30,60,90]); 
		
		
	//To check if any element of the array is even.
		function fnIsEven_loop(arr){ 
			for(var i = 0 ; i < arr.length; i ++){ 
				if(arr[i] % 2 === 0){ 
					return true; 
				} 
			} 
			return false; 
		} 
		fnIsEven_loop([1,3,5]); 
		fnIsEven_loop([1,3,5,6]); 
		
		
		function fnIsEven_some(arr){ 
			return arr.some(function(element){ 
				return(element %2 === 0): 
			}); 
		} 
		fnIsEven_some([1,3,5]); 
		fnIsEven_some([1,3,5,6]); 
		
		
		
		
/******** Array.Prototype.filter() ********/

	//Scenario where user has to remove all null values from an array.
		function fnFilterStudents_loop(aStudent){ 
			var tempArr = []; 
			for(var i = 0 ; i< aStudent.length; i ++){ 
				if(aStudent[i].fPercentage > 80.0){ 
					tempArr.push(aStudent[i]);
				} 
			} 
			return tempArr; 
		} 
		aStudent = [ 
			{sStudentId : "001" , fPercentage : 91.2}, 
			{sStudentId : "002" , fPercentage : 78.7}, 
			{sStudentId : "003" , fPercentage : 62.9}, 
			{sStudentId : "004" , fPercentage : 81.4}]; 
		console.log(fnFilterStudents_loop(aStudent)); 
			
			
		function fnFilterStudents_filter(aStudent){ 
			return aStudent.filter(function(oStudent){ 
				return oStudent.fPercentage > 80.0 ? true : false; 
            }); 
		} 
		aStudent = [ 
			{sStudentId : "001" , fPercentage : 91.2}, 
			{sStudentId : "002" , fPercentage : 78.7}, 
			{sStudentId : "003" , fPercentage : 62.9}, 
			{sStudentId : "004" , fPercentage : 81.4}]; 
		console.log(fnFilterStudents_filter(aStudent)); 
	

	//Scenario where user has to filter out the array based on value of a particular property of objects in the array.
		//Function to remove undefined elements from an array
		
		function removeUndefined(myArray){ 
			return myArray.filter(function(element, index, array){ 
				return element; 
			}); 
		}   
		var arr = [1,undefined,3,undefined,5];  
		console.log(arr); 
		console.log( removeUndefined(arr)); 
		
		
/******** Array.Prototype.map() *********/

	//Scenario where user has to reduce each amount in an array by a specific tax value
		
		//Function to add property bIsDistinction to each object in the array.
			
		function fnAddDistinction_loop(aStudent){ 
			for(var i = 0 ; i< aStudent.length; i ++){ 
				aStudent[i].bIsDistinction = (aStudent[i].fPercentage >= 75.0) ? true : false; 
            } 
			return aStudent; 
		} 
		aStudent = [ 
			{sStudentId : "001" , fPercentage : 91.2}, 
			{sStudentId : "002" , fPercentage : 78.7}, 
			{sStudentId : "003" , fPercentage : 62.9}, 
			{sStudentId : "004" , fPercentage : 81.4}];        
		console.log(fnAddDistinction_loop(aStudent));

		
		function fnAddDistinction_map(aStudent){ 
			return aStudent.map(function(student, index, array){ 
				aStudent.bIsDistinction = (aStudent.fPercentage >= 75.0) ? true : false; 
				return aStudent; 
			}); 
		} 
		aStudent = [ 
			{sStudentId : "001" , fPercentage : 91.2}, 
			{sStudentId : "002" , fPercentage : 78.7}, 
			{sStudentId : "003" , fPercentage : 62.9}, 
			{sStudentId : "004" , fPercentage : 81.4}]; 
		console.log(fnAddDistinction_map(aStudent)); 
		
		
	//Scenario where user has to create a new property of every object in an existing array of objects.
		
		//Scenario where Array.prototype.Map() is used with standard JavaScript functions.
		
		[1,4,9].map(Math.sqrt); // Output : [1,2,3] 
		["1.232","9.345","3.2345"].map(parseFloat) // Output : [1.232, 9.345, 3.2345] 
		["1","2","3"].map(parseInt); //Output : [1, NaN, NaN] 
		/**
			This happened because parseInt function accepts two arguments, 
			First one being the element to be parsed to Integer and second as the 
			radix which acts as base for conversion. 
			When we use it with Array.prototype.map(), although the first argument is 
			the element, the second argument is the index of the array element being 
			processed currently. 
			For first iteration, the index being 0 is passed as radix to parseInt which 
			defaults it to 10 and thus you see first element parsed successfully.
		**/
		["1","2","3"].map(function(val{return parseInt(val,10)}); // output : [1, 2, 3] 
		
		
		