

/*

Statically typed language where each variable and expression type is already known at compile time. 
Once a variable is declared to be of a certain data type, it cannot hold values of other data types.
Example: C, C++, Java.

// Java(Statically typed)
int x = 5 // variable x is of type int and it will not store any other type.
string y = ‘abc’ // type string and will only accept string values

Other, Dynamically typed languages: 
These languages can receive different data types over time. 
For example- Ruby, Python, JavaScript etc.

// Javascript(Dynamically typed)
var x = 5; // can store an integer
var name = ‘string’; // can also store a string. 

*/



/*
The latest ECMAScript(ES6) standard defines seven data types: 
Out of which six data types are Primitive(predefined).

Numbers: 5, 6.5, 7 etc.
String: “Hello GeeksforGeeks” etc.
Boolean: Represent a logical entity and can have two values: true or false.
Null: This type has only one value : null.
Undefined: A variable that has not been assigned a value is undefined.
Object: It is the most important data-type and forms the building blocks for modern JavaScript. 

*/


/* 

Variables in JavaScript are containers which hold reusable data. 
It is the basic unit of storage in a program.

The value stored in a variable can be changed during program execution.
A variable is only a name given to a memory location, all the operations done on the variable effects that memory location.
In JavaScript, all the variables must be declared before they can be used.

*/


/* Begins Defining Variables */


    var name; // declaring single variable
    var name, title, num; // declaring multiple variables
    var name = "Harsh"; // initializng variables
    name = "Rakesh";


    var num = 5; // creating variable to store a number
    num = "GeeksforGeeks"; // store string in the variable num


    var x = 5 + 10 + 1; // storing a mathematical expression
    console.log(x); // 16

    // let variable
    let x; // undefined
    let name = 'Mukul';


    let a=1,b=2,c=3; // can also declare multiple vlaues

    // assignment
    let a = 3;
    a = 4; // works same as var.

    // const variable
    const name = 'Mukul';
    name = 'Mayank'; // will give Assignment to constant variable error.


/* Ends Defining Variables */



/* Begins Defining Scope of Variables */


    /* Begins Case 1 */

        let globalLet = "This is a global variable"; 

        function fun() { 
        let localLet = "This is a local variable"; 

        console.log(globalLet); // This is a global variable 
        console.log(localLet); // This is a local variable 
        } 
        fun(); 

        //Both variables are executed

    /* Ends Case 1 */


    /* Begins Case 2 */

        let globalLet = "This is a global variable"; 

        function fun() { 
        let localLet = "This is a local variable"; 

        } 
        fun(); 
        console.log(globalLet); // This is a global variable 
        console.log(localLet); // localLet is not defined 

        //We didn't get local variable in console

    /* Ends Case 2 */


    /* Begins Case 3 */

        let globalLet = "This is a global variable"; 

        function fun() { 
        localLet = "This is a local variable"; 
        } 

        fun(); 
        console.log(globalLet); // This is a global variable 
        console.log(localLet); // This is a local variable 

        //We are now able to console.log the local variable as well because the localLet was created in the global scope as we missed the keyword let while declaring it

    /* Ends Case 3 */


    /* Begins Case 4 */

        let globalLet = "This is a global variable"; 

        function fun() { 
        let globalLet = "This is a local variable"; 
        } 
        fun(); 
        console.log(globalLet); // This is a global variable 

        //Shows global variable

    /* Ends Case 4 */


    /* Begins Case 5 */

        let globalLet = "This is a global variable"; 

        function fun() { 
        let globalLet = "This is a local variable"; 
        console.log(globalLet); // This is a local variable 
        } 
        fun(); 

        //Shows global variable

    /* Ends Case 5 */


    /* Begins Case 6 */

        let globalLet = "This is a global variable"; 

        function fun() { 
        let globalLet = "This is a local variable"; 
        console.log(window.globalLet); // This is a global variable 
        } 
        fun(); 

    /* Ends Case 6 */




    function fun(){ 
        function fun2(){ 
            i = 100; 
        } 
        fun2(); 
        console.log(i); // 100 
    } 
    fun(); 


    function fun(){ 
        function fun2(){ 
            let i = 100; 
        } 
        fun2(); 
        console.log(i); // i is not defined 
    } 
    fun(); 


    function fun(){ 
        if(true){ 
            let i = 100; 
        } 
        console.log(i); // i is not defined 
    } 
    fun(); 


/* Ends Defining Scope of Variables */


/* Begins IF-ELSE */

    var i = 20; 

    if (i == 10) 
    document.wrte("i is 10"); 
    else if (i == 15) 
    document.wrte("i is 15"); 
    else if (i == 20) 
    document.wrte("i is 20"); 
    else
    document.wrte("i is not present"); 


/* Ends TF-ELSE */




/* Begins Switch Case */

    var i = 9; 

    switch (i) 
    { 
    case 0: 
        document.write("i is zero."); 
        break; 
    case 1: 
        document.write("i is one."); 
        break; 
    case 2: 
        document.write("i is two."); 
        break; 
    default: 
        document.write("i is greater than 2."); 
    } 


/* Ends Switch Case */



