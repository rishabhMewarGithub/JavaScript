
/******************************************************************************************/


/**
Constructors are general JavaScript functions which are used with the “new” keyword. 
Constructors are of two types in JavaScript 
i.e. built-in constructors(array and object) 
and custom constructors(define properties and methods for specific objects)

Constructors can be useful when we need a way to create an object “type” that can be 
used multiple times without having to redefine the object every time and this could 
be achieved using the Object Constructor function.
 **/

function Automobile(color) {
    this.color = color;
}
var vehicle1 = new Automobile ("red");

/**
The function “Automobile()” is an object constructor, and its properties and methods 
i.e “color” is declared inside it by prefixing it with the keyword “this”. 

Objects defined using an object constructor are then made instants using the keyword “new”.

When new Automobile() is called, JavaScript does two things:
It creates a fresh new object(instance) Automobile() and assigns it to a variable.
It sets the constructor property i.e “color” of the object to Automobile.
**/


/******************************************************************************************/

/**
Object.entries(obj)
Parameters Used:
obj : It is the object whose enumerable own property [key, value] pairs are to be returned.
Return Value:
Object.entries() returns an array consisting of enumerable property [key, value] pairs of the object passed.
**/

/**
Object.entries() method is used to return an array consisting of enumerable property 
[key, value] pairs of the object which are passed as the parameter.
**/

// creating an object constructor and assigning values to it  
const obj = { 0: 'adam', 1: 'billy', 2: 'chris' }; 
// Displaying the enumerable property [key, value]  pairs of the object 
console.log(Object.entries(obj)[1]); // ["1", "billy"]

// creating an object constructor and assigning values to it 
const obj = { 10: 'adam', 200: 'billy', 35: 'chris' }; 
// Displaying the enumerable property [key, value]  pairs of the object 
console.log(Object.entries(obj));    // [ ["10", "adam"], ["35", "chris"], ["200", "billy"]] 

/**
Exceptions :
It causes a TypeError if the argument passed is not an object .
It causes a RangeError if the key passed in the argument is not in the range of the 
property[key, value] pair .
**/


/******************************************************************************************/


/**
Object.values(obj)
Parameters Used:
obj : It is the object whose enumerable property values are to be returned.
Return Value:
Object.values() returns an array containing all the enumerable property values of the given object.
**/

/**
Object.values() method in JavaScript returns an array whose elements are the enumerable 
property values found on the object. 
Object.values() is used for returning enumerable property values of an array like 
object with random key ordering.
**/

// Returning enumerable property values of a simple array  
check = ['x', 'y', 'z'];
console.log(Object.values(check)); // ["x", "y", "z"]

// Returning enumerable property values of an array like object.  
var object = { 0: '23', 1: 'geeksforgeeks', 2: 'true' };
console.log(Object.values(object)); // ["23", "geeksforgeeks", "true"]

// Returning enumerable property values of an array like object.  
var object = { 70: 'x', 21: 'y', 35: 'z' };
console.log(Object.values(object)); // ["y", "z", "x"]

/**
Exceptions :
It causes a TypeError if the argument passed is not an object .
If an object is not passed as an argument to the method, then it persuades it and 
treats it as an object.
**/


/******************************************************************************************/


/**
Object.create(prototype, [propertiesObject])
prototype : It is the prototype object from which a new object has to be created.
propertiesObject : It is optional parameter. It specifies the enumerable properties to be 
added to the newly created object.
**/

/**
Object.create() method is used to create a new object with the specified prototype object 
and properties. 
Object.create() method returns a new object with the specified prototype object and 
properties.
Object.create() is used for implementing inheritance.
**/

// creating a function which will be the prototype for the object to be created later
function fruits() { 
    this.name = 'fruit 1'; 
    this.season = 'summer'; 
}
// creating a function to whose object will inherit properties from the prototype 
function apple() { 
	fruits.call(this); 
}
// creating an object of the apple function which will have properties of the prototype object
apple.prototype = Object.create(fruits.prototype); 
const app = new apple(); 
// Displaying the created object
console.log(app.name);   // "fruit 1"
console.log(app.season); // "summer"

/**
Exceptions :
Object.create( ) method throws a TypeError exception if the propertiesObject parameter isn’t null.
Object.create( ) method throws a TypeError exception if the propertiesObject parameter is a non primitive object.
**/


/******************************************************************************************/


/**
Object.seal(obj)
Parameters Used:
obj : It is the object which has to be sealed.
Return Value:
Object.sealed() returns the object that was passed to the function.
**/

/**
Object.seal() which is used to seal an object. 
Sealing an object does not allow new properties to be added and marks all existing 
properties as non-configurable. 
Although values of present properties can be changed as long as they are writable.
The object to be sealed is passed as an argument and the method returns the object 
which has been sealed.
**/

/**
If an object is frozen using the Object.freeze() method 
then its properties become immutable and no changes can be made in them 
whereas if an object is sealed using the Object.seal() method 
then the changes can be made `in the existing properties of the object. 
**/

/**
Object.seal() is used for sealing objects and arrays.
Object.seal() is used to make an object immutable.
**/

// creating an object constructor and assigning values to it 
const obj1 = { property1: 'initial_data'}; 
// creating a second object which will seal the properties of the first object 
const obj2 = Object.seal(obj1); 
// Updating the properties of the frozen object 
obj2.property1 = 'new_data'; 
// Displaying the properties of the frozen object 
console.log(obj2.property1); // "new_data"


// creating an object constructor and assigning values to it 
var obj = { prop: function() {}, name: 'adam' }; 
// Displaying the properties of the object created 
console.log(obj); // Object { prop: function () {}, name: "adam" }
// Updating the properties of the object 
obj.name = 'billy'; 
delete obj.prop; 
// Displaying the updated properties of the object 
console.log(obj); // Object { name: "billy" }
// Sealing the object using object.seal() method 
var o = Object.seal(obj); 
// Updating the properties of the object 
delete obj.prop; 
// Displaying the updated properties of the object 
console.log(obj); // Object { name: "billy" }
// Updating the properties of the sealed object 
obj.name = 'chris'; 
// Displaying the properties of the frozen object 
console.log(obj); // Object { name: "chris" }


/**
Exceptions :
It causes a TypeError if the argument passed is not an object .
Deleting or adding properties to a sealed object will fail or throw a TypeError.
Converting a data property to accessor or its vice versa will throw a TypeError.
**/


/******************************************************************************************/


/**
Object.freeze(obj)
Parameters Used:
obj : It is the object which has to be freezed.
Return Value:
Object.freeze() returns the object that was passed to the function.
**/

/**
Freezing an object does not allow new properties to be added to an object and prevents 
from removing or altering the existing properties. 
Object.freeze() preserves the enumerability, configurability, writability and the 
prototype of the object. 
It returns the passed object and does not create a frozen copy.
**/

/**
Object.freeze() is used for freezing objects and arrays.
Object.freeze() is used to make an object immutable.
**/

//creating an object constructor and assigning values to it
const obj1 = { property1: 'initial_data'}; 
//creating a second object which will freeze the properties of the first object
const obj2 = Object.freeze(obj1); 
//Updating the properties of the frozen object 
obj2.property1 = 'new_data'; 
//Displaying the properties of the  frozen object 
console.log(obj2.property1);  // "initial_data"


//creating an object constructor and assigning values to it 
var obj = { prop: function() {}, name: 'adam' }; 
//Displaying the properties of the object created 
console.log(obj);  // Object { prop: function () {}, name: "adam" }
//Updating the properties of the object 
obj.name = 'billy'; 
delete obj.prop; 
//Displaying the updated properties of the object 
console.log(obj);  // Object { name: "billy" }
//Freezing the object using object.freeze() method> 
var o = Object.freeze(obj); // Object { name: "billy" }
//Updating the properties of the frozen object 
obj.name = 'chris'; 
//Displaying the properties of the  frozen object 
console.log(obj);  // Object { name: "billy" }

/**
Exceptions :
It causes a TypeError if the argument passed is not an object .
**/


/******************************************************************************************/


/**
Object.isFrozen(obj)
Parameters Used:
obj : It is the object which has to be checked.
Return Value:
Object.isFrozen() returns a boolean representing whether the object is frozen or not.
**/

/**
An object is frozen if all of the below-mentioned conditions hold true :
If it is not extensible.
If all of its properties are non-configurable.
If all its data properties are non-writable.
**/

//creating an object constructor and assigning values to it 
const object = { property: 'hi geeksforgeeks' }; 
//checking whether the object is frozen or not 
console.log(Object.isFrozen(object)); // false


//creating an object constructor and assigning values to it 
const object = { property: 'hi geeksforgeeks' }; 
//Using freeze() method to freeze the object 
Object.freeze(object); 
//checking whether the object is frozen or not 
console.log(Object.isFrozen(object)); // true

/**
Exceptions :
It causes a TypeError if the argument passed is not an object .
**/


/******************************************************************************************/


/**
Object.isSealed(obj)
Parameters Used:
obj : It is the object which has to be checked.
Return Value:
Object.isSealed() returns a boolean representing whether the object is sealed or not.
**/

/**
Object.isSealed() method is used to determine if an object is sealed or not.
An object is sealed if all of the below-mentioned conditions hold true :
If it is not extensible.
If all of its properties are non-configurable.
If it is not removable (but not necessarily non-writable).
**/

// creating an object constructor and assigning values to it  
const object = { property: 'hi geeksforgeeks'};  
// checking whether the object is sealed or not  
console.log(Object.isSealed(object)); // false


// creating an object constructor and assigning values to it  
const object = { property: 'hi geeksforgeeks'};   
// Using seal() method to seal the object 
Object.seal(object);  
// checking whether the object is frozen or not  
console.log(Object.isSealed(object)); //true

/**
Exceptions :
It causes a TypeError if the argument passed is not an object .
If an object is not passed as an argument to the method, then it treats it as a sealed 
object and returns true.
**/



/******************************************************************************************/


/**
Object.assign(target, ...sources)
Parameters Used:
target : It is the target object from which values and properties have to be copied.
sources : It is the source object to which values and properties have to be copied.
Return Value:
Object.assign() returns the target object.
**/

/**
Object.assign() is used to copy the values and properties from one or more source objects 
to a target object. 
It invokes getters and setters since it uses both [[Get]] on the source and [[Set]] on the 
target. 
It returns the target object which has properties and values copied from the target object. 
Object.assign() does not throw on null or undefined source values
**/

// creating an object constructor and assigning values to it 
const obj1 = { a: 1 }; 
// creating a target object and copying values and properties to it
const new_obj = Object.assign({}, obj1); 
// Displaying the target object 
console.log(new_obj); // Object { a: 1 }


// creating 3 object constructors and assigning values to it
var obj1 = { a: 10 }; 
var obj2 = { b: 20 }; 
var obj3 = { c: 30 }; 
//creating a target object and copying values and properties to it
var new_obj = Object.assign({}, obj1, obj2, obj3); 
// Displaying the target object 
console.log(new_obj); // Object { a: 10, b: 20, c: 30 }


// creating 3 object constructors and assigning values to it 
var obj1 = { a: 10, b: 10, c: 10 }; 
var obj2 = { b: 20, c: 20 }; 
var obj3 = { c: 30 }; 
//creating a target object and copying values and properties to it using object.assign() method 
var new_obj = Object.assign({}, obj1, obj2, obj3); 
// Displaying the target object 
console.log(new_obj); // Object { a: 10, b: 20, c: 30 }

/**
Errors and Exceptions
A TypeError is raised if the property is non-writable.
The target object can be changed only if the properties are added before the error is raised.
Object.assign() does not throw on null or undefined source values.
**/


/******************************************************************************************/


/**
Object.keys(obj)
Parameters Used:
obj : It is the object whose enumerable properties are to be returned.
Return Value:
Object.keys() returns an array of strings that represent all the enumerable properties of the given object.
**/

/**
Object.keys() method is used to return an array whose elements are strings corresponding to the enumerable properties found directly upon an object. 
Object.keys() is used for returning enumerable properties of a simple array.
Object.keys() is used for returning enumerable properties of an array like object.
Object.keys() is used for returning enumerable properties of an array like object with random key ordering.
**/

// Returning enumerable properties of a simple array  
var check = ['x', 'y', 'z']; 
console.log(Object.keys(check)); // ['0', '1', '2']

// Returning enumerable properties of an array like object. 
var object = { 0: 'x', 1: 'y', 2: 'z' }; 
console.log(Object.keys(object)); // ['0', '1', '2']

// Returning enumerable properties of an array like object with random key ordering. 
var object = { 70: 'x', 21: 'y', 35: 'z' }; 
console.log(Object.keys(object)); // ['21', '35', '70']

/**
Exceptions :
It causes a TypeError if the argument passed is not an object .
If an object is not passed as an argument to the method, then it persuades it and treats it as an object.
**/


/******************************************************************************************/


/**
Object.is(value1, value2)
Parameters Used:
value1 : It is the first value to be compared.
value1 : It is the second value to be compared.
Return Value:
Object.is() returns a boolean indicating whether the two arguments are same or not.
**/

/**
Object.is() method is used to determine whether two values are the same or not.
Two values can be same if they hold one of the following properties:
If both the values are undefined.
If both the values are null.
If both the values are true or false.
If both the strings are of the same length with the same characters and in the same order.
If both the values are numbers and both are “+0”.
If both the values are numbers and both are “-0”.
If both the values are numbers and both are “NaN” or both non-zero and both not NaN and both have the same value.
**/

/**
Difference between Object.is() method and “==” operator
The “==” and “===” operator treats the number values “+0” and “-0” as equal 
whereas Object.is() method treats them as not equal. 
Apart from that the “==” and “===” operator does not treat Number.Nan equal to Nan.
**/

/**
Object.is() is used for comparison of two strings.
Object.is() is used for comparison of two numbers.
Object.is() is used for comparing the polarity of two numbers.
Object.is() is used for comparison of two objects.
**/

// Comparing strings of the same length with the same characters in the same order   
Object.is('geeksforgeeks', 'geeksforgeeks'); // true

// Comapring two different strings 
Object.is('geeksforgeeks', 'gfg'); // false

// Comapring 0 and -0  
Object.is(0,-0); // false

// Comparing a variable with itself 
var check = { a: 100 }; 
Object.is(check, check); // false

/**
Exceptions :
The “==” and “===” operator treats the number values “+0” and “-0” as equal 
but the object.is() method treats them differently.
The Object.is() method does not coerce values before comparison even if they are of 
different data types.
**/


/******************************************************************************************/


/**
The window.history object contains the browsers history. 
First of all, window part can be removed from window.history just using history object 
alone works fine.
The JS history object contains an array of URLs visited by the user. 
By using history object, you can load previous, forward or any particular page 
using various methods.
**/

/**
Property of JavaScript history object :
length: It returns the length of the history URLs visited by user in that session.
**/

/**
Methods of JavaScript history object :
forward(): It loads the next page. Provides a same effect as clicking back in the browser.
back(): It loads the previous page. Provides a same effect as clicking forward in the browser.
go(): It loads the given page number in browser. history.go(distance) function provides a 
same effect as pressing the back or forward button in your browser and specifying the page 
exactly which you want to load.
**/

<body> 
	<b>Press the back button</b> 
	<input type="button" value="Back" onclick="previousPage()"> 
	<script> 
		function previousPage() { 
			window.history.back(); 
		} 
	</script> 
</body> 

<body> 
	<b>Press the back button</b> 
	<input type="button" value="Back" onclick="NextPage()"> 
	<script> 
		function NextPage() { 
			window.history.forward(); 
		} 
	</script> 
</body> 

<body> 
	<b>Press the back button</b> 
	<input type="button" value="Back" onclick="NextPage()"> 
	<script> 
		function NextPage() { 
			window.history.go(4); 
		} 
	</script> 
</body> 

<body> 
	<b>Press the back button</b> 
	<input type="button" value="Back" onclick="previousPage()"> 
	<script> 
		function NextPage() { 
			window.history.go(-4); 
		} 
	</script> 
</body>



/******************************************************************************************/


/**
The proxy object in JavaScript is used to define the custom behavior of fundamental 
operations (e.g. property lookup, assignment, enumeration, function invocation, etc).
**/

/**
var p = new Proxy(target, handler);
target: A target object (can be any sort of object including a function, class, 
or even another proxy) to wrap with Proxy.
handler: An object whose properties are functions which define the behavior of the 
proxy when an operation is performed on it.
**/

const Person = { 
    Name: 'John Nash', 
    Age: 25 
}; 
const handler = { 
    // target represents the Person while prop represents proxy property. 
    get: function(target, prop) { 
        if (prop === 'FirstName') { 
            return target.Name.split(' ')[0]; 
        } 
        if (prop === 'LastName') { 
            return target.Name.split(' ').pop(); 
        } 
        else { 
            return Reflect.get(target,prop); 
        } 
    } 
}; 
const proxy1 = new Proxy(Person, handler); 
document.write(proxy1 + "<br>"); 
// Though there is no Property as FirstName and LastName, still we get them as if they were property not function. 
document.write(proxy1.FirstName + "<br>"); 
document.write(proxy1.LastName  + "<br>");      


/******** How to use a variable for a key in a JavaScript object literal? *******/

//syntax:
var key="your_choice";
var object = {};
object[key] = "your_choice";
console.log(object);


/******** How to swap key and value of JSON object  using JavaScript ? **********/

//Approach
Create a new empty object.
For each key of the object, add the elements from old object to the new object in reverse 
form (by swapping the key and values). Using .ForEach() method

function swapValues(o) { 
            const res = {}; 
            Object.keys(o).forEach(key => { 
                res[o[key]] = key; 
            }); 
            return res; 
} 


/******* How to iterate over a JavaScript object ? *******/

//Approach 1 Using for…in loop
function iterateObject() { 
            let exampleObj = { 
                book: "Sherlock Holmes", 
                author: "Arthur Conan Doyle", 
                genre: "Mystery" 
            }; 
      
            for (let key in exampleObj) { 
                if (exampleObj.hasOwnProperty(key)) 
                { 
                    value = exampleObj[key]; 
                    console.log(key, value); 
                } 
            } 
} 

//Approach 2 Object.entries() map
function iterateObject() { 
            let exampleObj = { 
                book: "Sherlock Holmes", 
                author: "Arthur Conan Doyle", 
                genre: "Mystery" 
            }; 
      
            Object.entries(exampleObj).map(entry => { 
                let key = entry[0]; 
                let value = entry[1]; 
                console.log(key, value); 
            }); 
} 


/**************** How to get the last item of JavaScript object ? **********************/


//Approach 1 Object.keys() 

		var up1 = document.getElementById('GFG_UP1');  
        var up2 = document.getElementById('GFG_UP2');  
        var down = document.getElementById('GFG_DOWN');  
          
        var Obj = {  
            "1_prop": "1_Val",  
            "2_prop": "2_Val",  
            "3_prop": "3_Val"  
        };  
          
        up1.innerHTML = "Click on the button to get" 
                + "the last element of the Object.";  
          
        up2.innerHTML = JSON.stringify(Obj);  
          
        function GFG_Fun() {  
            down.innerHTML = "The last key = '" +  
                Object.keys(Obj)[Object.keys(Obj).length-1] 
                + "' <br> Value = '"  
                + Obj[Object.keys(Obj)[Object.keys(Obj).length-1]] 
                + "'";  
        }  


/************** How to remove Objects from Associative Array in JavaScript ? *********/
        // JavaScript code to remove objects from associative array 
        function deleteObjects(){     
		
            // Declaring an associative array of objects 
            var arr = new Object(); 
                  
            // Adding objects in array 
            arr['key'] = 'Value'; 
            arr['geeks'] = 'GeeksforGeeks'; 
            arr['name'] = 'Rajnish'; 
                  
            // Checking object exist or not 
            document.write(arr['name'] + '</br>'); 
                  
            // Removing object from associative array 
            delete arr['name']; 
                  
            // It gives result as undefined as object is deleted 
            document.write(arr['name'] + '</br>'); 
        } 
              
        // Calling function 
        deleteObjects(); 

		
/**** How to compare two JavaScript array objects using jQuery/JavaScript ? ********/			

		var up = document.getElementById('GFG_UP'); 
        var down = document.getElementById('GFG_DOWN'); 
        var arr1 = [1, 3, 7, 5]; 
        var arr2 = [1, 3, 5, 7]; 
          
        up.innerHTML = "Click on the button to check " 
                + "equality of arrays.<br>Array1 - "  
                + arr1 + "<br>Array2 - " + arr2; 
          
        function compare(ar1, ar2) { 
            ar1.sort(); 
            ar2.sort(); 
              
            if(ar1.length != ar2.length) 
                return false; 
              
            for(var i = 0; i < ar1.length; i++) { 
                if (ar1[i] != ar2[i]) 
                    return false; 
            } 
            return true; 
        } 
        function GFG_Fun() { 
            down.innerHTML = compare(arr1, arr2); 
        }  















